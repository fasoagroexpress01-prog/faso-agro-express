/**
 * BACKEND API - Application E30 (Équipe de 30 producteurs)
 * -----------------------------------------------------------
 * À copier-coller dans l'éditeur Apps Script de ton Google Sheet.
 * Voir GUIDE_INSTALLATION.md pour les instructions pas à pas.
 *
 * Structure attendue du Google Sheet :
 *
 * Feuille "Utilisateurs" (colonnes) :
 *   A: id | B: identifiant | C: motDePasse | D: role | E: nomComplet
 *   role = "Administration" | "Superviseur" | "Facilitateur" | "Equipe E30"
 *
 * Feuille "Producteurs" (colonnes) :
 *   A: id | B: nom | C: prenom | D: telephone | E: email
 *   F: role | G: dateInscription | H: statut | I: creePar
 */

const SHEET_UTILISATEURS = "Utilisateurs";
const SHEET_PRODUCTEURS = "Producteurs";

// ============ POINT D'ENTRÉE PRINCIPAL ============

function doGet(e) {
  return handleRequest(e);
}

function doPost(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  try {
    let params = {};
    if (e.postData && e.postData.contents) {
      params = JSON.parse(e.postData.contents);
    } else {
      params = e.parameter;
    }

    const action = params.action;
    let result;

    switch (action) {
      case "login":
        result = login(params.identifiant, params.motDePasse);
        break;
      case "listProducteurs":
        result = listProducteurs();
        break;
      case "addProducteur":
        // params.data est déjà un objet JS (envoyé en JSON depuis l'app Android)
        result = addProducteur(params.data, params.identifiant);
        break;
      case "updateProducteur":
        result = updateProducteur(params.id, params.data, params.identifiant);
        break;
      case "deleteProducteur":
        result = deleteProducteur(params.id, params.identifiant);
        break;
      default:
        result = { success: false, message: "Action inconnue: " + action };
    }

    return jsonResponse(result);
  } catch (err) {
    return jsonResponse({ success: false, message: "Erreur serveur: " + err.message });
  }
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============ AUTHENTIFICATION ============

function login(identifiant, motDePasse) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_UTILISATEURS);
  const data = sheet.getDataRange().getValues();

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (row[1] === identifiant && String(row[2]) === String(motDePasse)) {
      return {
        success: true,
        user: {
          id: row[0],
          identifiant: row[1],
          role: row[3],
          nomComplet: row[4]
        }
      };
    }
  }
  return { success: false, message: "Identifiant ou mot de passe incorrect." };
}

// ============ PERMISSIONS PAR RÔLE ============

function getRoleOf(identifiant) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_UTILISATEURS);
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (data[i][1] === identifiant) return data[i][3];
  }
  return null;
}

function peutModifierTout(role) {
  // Administration et Superviseur gèrent tous les producteurs
  return role === "Administration" || role === "Superviseur";
}

// ============ GESTION DES PRODUCTEURS ============

function listProducteurs() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUCTEURS);
  const data = sheet.getDataRange().getValues();
  const producteurs = [];

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (!row[0]) continue;
    producteurs.push({
      id: row[0],
      nom: row[1],
      prenom: row[2],
      telephone: row[3],
      email: row[4],
      role: row[5],
      dateInscription: row[6],
      statut: row[7],
      creePar: row[8]
    });
  }
  return { success: true, producteurs: producteurs };
}

function addProducteur(data, identifiant) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUCTEURS);
  const newId = Utilities.getUuid();
  const dateInscription = data.dateInscription || Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd");

  sheet.appendRow([
    newId,
    data.nom,
    data.prenom,
    data.telephone,
    data.email,
    data.role,
    dateInscription,
    data.statut || "Actif",
    identifiant
  ]);

  return { success: true, id: newId };
}

function updateProducteur(id, data, identifiant) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUCTEURS);
  const values = sheet.getDataRange().getValues();
  const role = getRoleOf(identifiant);

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === id) {
      // Un rôle non-admin ne peut modifier que sa propre fiche (créée par lui)
      if (!peutModifierTout(role) && values[i][8] !== identifiant) {
        return { success: false, message: "Tu n'as pas la permission de modifier cette fiche." };
      }
      const rowIndex = i + 1;
      sheet.getRange(rowIndex, 2, 1, 7).setValues([[
        data.nom, data.prenom, data.telephone, data.email,
        data.role, data.dateInscription, data.statut
      ]]);
      return { success: true };
    }
  }
  return { success: false, message: "Producteur introuvable." };
}

function deleteProducteur(id, identifiant) {
  const role = getRoleOf(identifiant);
  if (!peutModifierTout(role)) {
    return { success: false, message: "Seuls Administration et Superviseur peuvent supprimer." };
  }

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_PRODUCTEURS);
  const values = sheet.getDataRange().getValues();

  for (let i = 1; i < values.length; i++) {
    if (values[i][0] === id) {
      sheet.deleteRow(i + 1);
      return { success: true };
    }
  }
  return { success: false, message: "Producteur introuvable." };
}
