# Guide d'installation — Backend E30 (Google Sheets)

## Étape 1 — Crée le Google Sheet

1. Va sur [sheets.google.com](https://sheets.google.com) → **Nouveau classeur vide**
2. Renomme-le : `Base E30`
3. En bas, renomme l'onglet "Feuille 1" en **`Utilisateurs`**
4. Ajoute une deuxième feuille (bouton `+` en bas) et nomme-la **`Producteurs`**

## Étape 2 — Remplis la feuille "Utilisateurs"

Dans la feuille `Utilisateurs`, ligne 1 (en-têtes), colle exactement :

| A | B | C | D | E |
|---|---|---|---|---|
| id | identifiant | motDePasse | role | nomComplet |

Puis ajoute une ligne par personne, exemple ligne 2 :

| 1 | admin | Admin2026! | Administration | Jean Dupont |

Le champ **role** doit être écrit EXACTEMENT : `Administration`, `Superviseur`, `Facilitateur`, ou `Equipe E30`.

## Étape 3 — Remplis la feuille "Producteurs"

Dans la feuille `Producteurs`, ligne 1 (en-têtes) :

| A | B | C | D | E | F | G | H | I |
|---|---|---|---|---|---|---|---|---|
| id | nom | prenom | telephone | email | role | dateInscription | statut | creePar |

Laisse le reste vide, l'app remplira automatiquement les lignes.

## Étape 4 — Installe le script

1. Dans ton Sheet : menu **Extensions → Apps Script**
2. Supprime tout le code par défaut (`function myFunction()...`)
3. Colle le contenu du fichier **Code.gs** fourni
4. Clique sur 💾 **Enregistrer** (nomme le projet "API E30")

## Étape 5 — Déploie comme application web

1. En haut à droite : **Déployer → Nouveau déploiement**
2. Clique sur l'icône ⚙️ à côté de "Sélectionner le type" → choisis **Application web**
3. Configure :
   - **Exécuter en tant que** : Moi (ton compte)
   - **Qui a accès** : **Tout le monde**
4. Clique **Déployer**
5. Google va te demander d'autoriser l'accès → clique **Autoriser**, choisis ton compte, puis **Avancé → Accéder à API E30 (non sécurisé) → Autoriser**
6. Une **URL** va apparaître, du type :
   `https://script.google.com/macros/s/AKfycb.../exec`
7. **Copie cette URL** — c'est elle que tu me donneras (ou que tu colleras dans l'app) pour connecter l'application Android à ton Sheet.

⚠️ Chaque fois que tu modifies le code du script, il faut refaire **Déployer → Gérer les déploiements → ✏️ Modifier → Nouvelle version → Déployer** pour que les changements soient pris en compte.

## Étape 6 — Teste

Ouvre l'URL obtenue dans un navigateur en ajoutant `?action=listProducteurs` à la fin, par exemple :
`https://script.google.com/macros/s/AKfycb.../exec?action=listProducteurs`

Tu dois voir : `{"success":true,"producteurs":[]}`

Si oui, c'est prêt ! Donne-moi cette URL pour que je la mette dans le code Android.
