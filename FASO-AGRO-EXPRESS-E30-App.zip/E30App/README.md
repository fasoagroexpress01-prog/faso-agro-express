# FASO AGRO-EXPRESS — Application E30

Application Android d'enregistrement des membres de l'Équipe de 30 producteurs,
synchronisée avec Google Sheets.

## Contenu du dossier

- **apps-script/** → le backend (à installer côté Google Sheets)
  - `Code.gs` : code à coller dans Apps Script
  - `GUIDE_INSTALLATION.md` : étapes pas à pas pour créer le Sheet et déployer l'API
- **android/** → le projet Android Studio (l'application mobile)

## Marche à suivre

### 1. Backend (5-10 min)
Suis `apps-script/GUIDE_INSTALLATION.md` en entier. À la fin, tu obtiens une URL
du type `https://script.google.com/macros/s/XXXX/exec`.

### 2. Application Android
1. Installe [Android Studio](https://developer.android.com/studio) si ce n'est pas déjà fait
2. Ouvre le dossier `android/` avec Android Studio (**File → Open**)
3. Laisse Gradle synchroniser (peut prendre quelques minutes la première fois)
4. Branche ton téléphone (mode débogage USB activé) ou utilise un émulateur
5. Clique sur ▶️ **Run** pour installer l'app

### 3. Générer le fichier APK à installer directement
Dans Android Studio : **Build → Build Bundle(s)/APK(s) → Build APK(s)**
Le fichier `.apk` sera généré dans `android/app/build/outputs/apk/debug/`.
Tu peux ensuite l'envoyer sur ton téléphone (WhatsApp, câble USB, etc.) et l'installer
(autorise "Sources inconnues" dans les paramètres Android si demandé).

### 4. Première connexion
Au premier lancement, colle :
- l'**URL de l'API** obtenue à l'étape 1
- l'**identifiant / mot de passe** d'un compte créé dans la feuille `Utilisateurs`

## Rôles et permissions

| Rôle | Peut gérer tous les producteurs | Peut modifier ses propres fiches | Peut supprimer |
|---|---|---|---|
| Administration | ✅ | ✅ | ✅ |
| Superviseur | ✅ | ✅ | ✅ |
| Facilitateur | ❌ | ✅ (celles qu'il a créées) | ❌ |
| Equipe E30 | ❌ | ✅ (celles qu'il a créées) | ❌ |

## Pour aller plus loin
Dis-moi si tu veux que j'ajoute : export PDF/Excel de la liste, statistiques par
région, photo de profil des producteurs, notifications, ou une version iOS.
