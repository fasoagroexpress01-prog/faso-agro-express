package com.e30.equipe.util

import android.content.Context
import com.e30.equipe.data.Utilisateur

/**
 * Stocke la session (utilisateur connecté) et l'URL de l'API Apps Script
 * localement sur l'appareil, entre deux ouvertures de l'app.
 */
class SessionManager(context: Context) {

    private val prefs = context.getSharedPreferences("e30_session", Context.MODE_PRIVATE)

    var apiUrl: String
        get() = prefs.getString("api_url", "") ?: ""
        set(value) = prefs.edit().putString("api_url", value).apply()

    fun saveUser(user: Utilisateur) {
        prefs.edit()
            .putString("id", user.id)
            .putString("identifiant", user.identifiant)
            .putString("role", user.role)
            .putString("nomComplet", user.nomComplet)
            .apply()
    }

    fun getUser(): Utilisateur? {
        val identifiant = prefs.getString("identifiant", null) ?: return null
        return Utilisateur(
            id = prefs.getString("id", "") ?: "",
            identifiant = identifiant,
            role = prefs.getString("role", "") ?: "",
            nomComplet = prefs.getString("nomComplet", "") ?: ""
        )
    }

    fun logout() {
        prefs.edit()
            .remove("id").remove("identifiant").remove("role").remove("nomComplet")
            .apply()
    }
}
