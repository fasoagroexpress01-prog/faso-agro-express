package com.e30.equipe.ui.producteurs

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.e30.equipe.data.ApiClient
import com.e30.equipe.data.Producteur
import com.e30.equipe.data.Roles
import com.e30.equipe.databinding.ActivityProducteurListBinding
import com.e30.equipe.ui.login.LoginActivity
import com.e30.equipe.util.SessionManager
import kotlinx.coroutines.launch

class ProducteurListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProducteurListBinding
    private lateinit var session: SessionManager
    private lateinit var apiClient: ApiClient
    private lateinit var adapter: ProducteurAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProducteurListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        val user = session.getUser()

        if (user == null || session.apiUrl.isBlank()) {
            goToLogin()
            return
        }

        apiClient = ApiClient(session.apiUrl)
        supportActionBar?.title = "Équipe E30 — ${user.role}"

        val peutTout = Roles.peutGererTout(user.role)

        adapter = ProducteurAdapter(
            peutModifier = { p -> peutTout || p.creePar == user.identifiant },
            peutSupprimer = { peutTout },
            onEdit = { p -> openEdit(p) },
            onDelete = { p -> confirmerSuppression(p) }
        )

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddEditProducteurActivity::class.java))
        }

        binding.swipeRefresh.setOnRefreshListener { chargerListe() }

        chargerListe()
    }

    override fun onResume() {
        super.onResume()
        if (::apiClient.isInitialized) chargerListe()
    }

    private fun chargerListe() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                val result = apiClient.listProducteurs()
                if (result.optBoolean("success")) {
                    val arr = result.getJSONArray("producteurs")
                    val liste = mutableListOf<Producteur>()
                    for (i in 0 until arr.length()) {
                        liste.add(Producteur.fromJson(arr.getJSONObject(i)))
                    }
                    adapter.submitList(liste)
                    binding.emptyView.visibility =
                        if (liste.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
                } else {
                    Toast.makeText(this@ProducteurListActivity, result.optString("message"), Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ProducteurListActivity, "Erreur de chargement", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun openEdit(p: Producteur) {
        val intent = Intent(this, AddEditProducteurActivity::class.java)
        intent.putExtra(AddEditProducteurActivity.EXTRA_ID, p.id)
        intent.putExtra(AddEditProducteurActivity.EXTRA_NOM, p.nom)
        intent.putExtra(AddEditProducteurActivity.EXTRA_PRENOM, p.prenom)
        intent.putExtra(AddEditProducteurActivity.EXTRA_TELEPHONE, p.telephone)
        intent.putExtra(AddEditProducteurActivity.EXTRA_EMAIL, p.email)
        intent.putExtra(AddEditProducteurActivity.EXTRA_ROLE, p.role)
        intent.putExtra(AddEditProducteurActivity.EXTRA_DATE, p.dateInscription)
        intent.putExtra(AddEditProducteurActivity.EXTRA_STATUT, p.statut)
        startActivity(intent)
    }

    private fun confirmerSuppression(p: Producteur) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer ce producteur ?")
            .setMessage("${p.prenom} ${p.nom} sera supprimé définitivement.")
            .setPositiveButton("Supprimer") { _, _ ->
                lifecycleScope.launch {
                    val user = session.getUser()!!
                    val result = apiClient.deleteProducteur(user.identifiant, p.id)
                    if (result.optBoolean("success")) {
                        chargerListe()
                    } else {
                        Toast.makeText(this@ProducteurListActivity, result.optString("message"), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(com.e30.equipe.R.menu.menu_list, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == com.e30.equipe.R.id.action_logout) {
            session.logout()
            goToLogin()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
