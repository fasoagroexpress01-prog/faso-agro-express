package com.e30.equipe.ui.producteurs

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.e30.equipe.data.Producteur
import com.e30.equipe.databinding.ItemProducteurBinding

class ProducteurAdapter(
    private val peutModifier: (Producteur) -> Boolean,
    private val peutSupprimer: (Producteur) -> Boolean,
    private val onEdit: (Producteur) -> Unit,
    private val onDelete: (Producteur) -> Unit
) : RecyclerView.Adapter<ProducteurAdapter.ViewHolder>() {

    private val items = mutableListOf<Producteur>()

    fun submitList(newItems: List<Producteur>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemProducteurBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class ViewHolder(private val binding: ItemProducteurBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(p: Producteur) {
            binding.textNom.text = "${p.prenom} ${p.nom}"
            binding.textDetails.text = "${p.role} • ${p.telephone}"
            binding.textStatut.text = p.statut
            binding.textStatut.setTextColor(
                if (p.statut == "Actif") 0xFF2E7D32.toInt() else 0xFF9E9E9E.toInt()
            )

            val modifiable = peutModifier(p)
            val supprimable = peutSupprimer(p)

            binding.root.setOnClickListener { if (modifiable) onEdit(p) }
            binding.buttonDelete.visibility = if (supprimable) View.VISIBLE else View.GONE
            binding.buttonDelete.setOnClickListener { onDelete(p) }
        }
    }
}
