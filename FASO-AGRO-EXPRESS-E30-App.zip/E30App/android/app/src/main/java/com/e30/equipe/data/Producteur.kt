package com.e30.equipe.data

import org.json.JSONObject

data class Producteur(
    val id: String,
    var nom: String,
    var prenom: String,
    var telephone: String,
    var email: String,
    var role: String,
    var dateInscription: String,
    var statut: String,
    val creePar: String
) {
    companion object {
        fun fromJson(o: JSONObject): Producteur {
            return Producteur(
                id = o.optString("id"),
                nom = o.optString("nom"),
                prenom = o.optString("prenom"),
                telephone = o.optString("telephone"),
                email = o.optString("email"),
                role = o.optString("role"),
                dateInscription = o.optString("dateInscription"),
                statut = o.optString("statut"),
                creePar = o.optString("creePar")
            )
        }
    }
}

data class Utilisateur(
    val id: String,
    val identifiant: String,
    val role: String,
    val nomComplet: String
) {
    companion object {
        fun fromJson(o: JSONObject): Utilisateur {
            return Utilisateur(
                id = o.optString("id"),
                identifiant = o.optString("identifiant"),
                role = o.optString("role"),
                nomComplet = o.optString("nomComplet")
            )
        }
    }
}

object Roles {
    const val ADMINISTRATION = "Administration"
    const val SUPERVISEUR = "Superviseur"
    const val FACILITATEUR = "Facilitateur"
    const val EQUIPE_E30 = "Equipe E30"

    // Administration et Superviseur peuvent gérer tous les producteurs.
    fun peutGererTout(role: String): Boolean =
        role == ADMINISTRATION || role == SUPERVISEUR
}
