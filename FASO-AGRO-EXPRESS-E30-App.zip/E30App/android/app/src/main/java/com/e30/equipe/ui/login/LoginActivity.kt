package com.e30.equipe.ui.login

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.e30.equipe.data.ApiClient
import com.e30.equipe.data.Utilisateur
import com.e30.equipe.databinding.ActivityLoginBinding
import com.e30.equipe.ui.producteurs.ProducteurListActivity
import com.e30.equipe.util.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)

        // Si déjà connecté, on saute directement à la liste
        if (session.getUser() != null && session.apiUrl.isNotBlank()) {
            goToList()
            return
        }

        // Pré-remplir l'URL de l'API si déjà configurée une fois
        binding.editApiUrl.setText(session.apiUrl)

        binding.buttonLogin.setOnClickListener { doLogin() }
    }

    private fun doLogin() {
        val apiUrl = binding.editApiUrl.text.toString().trim()
        val identifiant = binding.editIdentifiant.text.toString().trim()
        val motDePasse = binding.editMotDePasse.text.toString()

        if (apiUrl.isBlank()) {
            Toast.makeText(this, "Colle l'URL de l'API Google Sheets (voir GUIDE_INSTALLATION.md)", Toast.LENGTH_LONG).show()
            return
        }
        if (identifiant.isBlank() || motDePasse.isBlank()) {
            Toast.makeText(this, "Renseigne ton identifiant et ton mot de passe", Toast.LENGTH_SHORT).show()
            return
        }

        binding.buttonLogin.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            try {
                val client = ApiClient(apiUrl)
                val result = client.login(identifiant, motDePasse)

                if (result.optBoolean("success")) {
                    val user = Utilisateur.fromJson(result.getJSONObject("user"))
                    session.apiUrl = apiUrl
                    session.saveUser(user)
                    goToList()
                } else {
                    Toast.makeText(
                        this@LoginActivity,
                        result.optString("message", "Connexion échouée"),
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@LoginActivity,
                    "Erreur de connexion : vérifie l'URL et ta connexion internet",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                binding.buttonLogin.isEnabled = true
                binding.progress.visibility = android.view.View.GONE
            }
        }
    }

    private fun goToList() {
        startActivity(Intent(this, ProducteurListActivity::class.java))
        finish()
    }
}
