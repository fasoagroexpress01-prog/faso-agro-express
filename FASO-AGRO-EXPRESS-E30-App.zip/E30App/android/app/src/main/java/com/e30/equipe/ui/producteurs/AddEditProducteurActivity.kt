package com.e30.equipe.ui.producteurs

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.e30.equipe.data.ApiClient
import com.e30.equipe.data.Producteur
import com.e30.equipe.databinding.ActivityAddEditProducteurBinding
import com.e30.equipe.util.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AddEditProducteurActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "id"
        const val EXTRA_NOM = "nom"
        const val EXTRA_PRENOM = "prenom"
        const val EXTRA_TELEPHONE = "telephone"
        const val EXTRA_EMAIL = "email"
        const val EXTRA_ROLE = "role"
        const val EXTRA_DATE = "date"
        const val EXTRA_STATUT = "statut"

        val ROLES = listOf("Administration", "Superviseur", "Facilitateur", "Equipe E30")
        val STATUTS = listOf("Actif", "Inactif")
    }

    private lateinit var binding: ActivityAddEditProducteurBinding
    private lateinit var session: SessionManager
    private lateinit var apiClient: ApiClient
    private var producteurId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditProducteurBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        apiClient = ApiClient(session.apiUrl)

        binding.spinnerRole.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, ROLES)
        binding.spinnerStatut.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, STATUTS)

        producteurId = intent.getStringExtra(EXTRA_ID)

        if (producteurId != null) {
            supportActionBar?.title = "Modifier le producteur"
            binding.editNom.setText(intent.getStringExtra(EXTRA_NOM))
            binding.editPrenom.setText(intent.getStringExtra(EXTRA_PRENOM))
            binding.editTelephone.setText(intent.getStringExtra(EXTRA_TELEPHONE))
            binding.editEmail.setText(intent.getStringExtra(EXTRA_EMAIL))
            val roleIndex = ROLES.indexOf(intent.getStringExtra(EXTRA_ROLE)).coerceAtLeast(0)
            binding.spinnerRole.setSelection(roleIndex)
            val statutIndex = STATUTS.indexOf(intent.getStringExtra(EXTRA_STATUT)).coerceAtLeast(0)
            binding.spinnerStatut.setSelection(statutIndex)
        } else {
            supportActionBar?.title = "Ajouter un producteur"
        }

        binding.buttonSave.setOnClickListener { save() }
    }

    private fun save() {
        val nom = binding.editNom.text.toString().trim()
        val prenom = binding.editPrenom.text.toString().trim()
        val telephone = binding.editTelephone.text.toString().trim()
        val email = binding.editEmail.text.toString().trim()
        val role = binding.spinnerRole.selectedItem.toString()
        val statut = binding.spinnerStatut.selectedItem.toString()

        if (nom.isBlank() || prenom.isBlank() || telephone.isBlank()) {
            Toast.makeText(this, "Nom, prénom et téléphone sont obligatoires", Toast.LENGTH_SHORT).show()
            return
        }

        val user = session.getUser()!!
        val dateInscription = intent.getStringExtra(EXTRA_DATE)
            ?: SimpleDateFormat("yyyy-MM-dd", Locale.FRANCE).format(Date())

        val producteur = Producteur(
            id = producteurId ?: "",
            nom = nom,
            prenom = prenom,
            telephone = telephone,
            email = email,
            role = role,
            dateInscription = dateInscription,
            statut = statut,
            creePar = user.identifiant
        )

        binding.buttonSave.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            try {
                val result = if (producteurId != null) {
                    apiClient.updateProducteur(user.identifiant, producteur)
                } else {
                    apiClient.addProducteur(user.identifiant, producteur)
                }

                if (result.optBoolean("success")) {
                    Toast.makeText(this@AddEditProducteurActivity, "Enregistré avec succès", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@AddEditProducteurActivity, result.optString("message"), Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@AddEditProducteurActivity, "Erreur : vérifie ta connexion", Toast.LENGTH_LONG).show()
            } finally {
                binding.buttonSave.isEnabled = true
                binding.progress.visibility = android.view.View.GONE
            }
        }
    }
}
