package com.e30.equipe.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Envoie les requêtes vers le Web App Google Apps Script (voir GUIDE_INSTALLATION.md).
 * baseUrl = l'URL ".../exec" obtenue après déploiement du script.
 */
class ApiClient(private val baseUrl: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private suspend fun post(body: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(baseUrl)
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val text = response.body?.string() ?: "{}"
            JSONObject(text)
        }
    }

    suspend fun login(identifiant: String, motDePasse: String): JSONObject {
        return post(
            JSONObject()
                .put("action", "login")
                .put("identifiant", identifiant)
                .put("motDePasse", motDePasse)
        )
    }

    suspend fun listProducteurs(): JSONObject {
        return post(JSONObject().put("action", "listProducteurs"))
    }

    private fun producteurData(p: Producteur): JSONObject = JSONObject()
        .put("nom", p.nom)
        .put("prenom", p.prenom)
        .put("telephone", p.telephone)
        .put("email", p.email)
        .put("role", p.role)
        .put("dateInscription", p.dateInscription)
        .put("statut", p.statut)

    suspend fun addProducteur(identifiant: String, p: Producteur): JSONObject {
        return post(
            JSONObject()
                .put("action", "addProducteur")
                .put("identifiant", identifiant)
                .put("data", producteurData(p))
        )
    }

    suspend fun updateProducteur(identifiant: String, p: Producteur): JSONObject {
        return post(
            JSONObject()
                .put("action", "updateProducteur")
                .put("identifiant", identifiant)
                .put("id", p.id)
                .put("data", producteurData(p))
        )
    }

    suspend fun deleteProducteur(identifiant: String, id: String): JSONObject {
        return post(
            JSONObject()
                .put("action", "deleteProducteur")
                .put("identifiant", identifiant)
                .put("id", id)
        )
    }
}
